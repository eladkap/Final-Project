﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Lab
{
    public partial class Form1 : Form
    {    
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Exit application", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        /*
        private void connectToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try {
                connector = new DatabaseConnector();
                connector.ConnectToDatabase();
                disconnectToolStripMenuItem.Visible = true;
                connectToolStripMenuItem1.Visible = false;
                MessageBox.Show("Connected successfully.", "Connecting to database", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ee)
            {
                MessageBox.Show("Connection failed.","Connecting to database",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        
        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            connector?.DisconnectFromDatabase();
            disconnectToolStripMenuItem.Visible = false;
            connectToolStripMenuItem1.Visible = true;
            MessageBox.Show("Disonnected successfully.", "Disonnecting from database", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        */
    }
}
