﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Final_Lab
{
    public class XmlDecoder
    {
        public Item DeserializeItem(string path)
        {
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(Item));
                StreamReader reader = new StreamReader(path);
                Item item = (Item)xmlSerializer.Deserialize(reader);
                return item;
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}
